<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="csshome/stylee.css">    </head>

</head>
<body>

    <div class="hero-image">
      <div class="hero-text">
      	<center>
        <h2>PENDAFTARAN PESERTA DIDIK BARU TAHUN 2020-2021</h2>
        <h2>SMK Wikrama 1 Garut</h2>

        </center>
          <form action="index.php">
          	<center>
            <input type="submit" value="Daftar" action="index.php">
            </center>
          </form>
      </div>
    </div>

</body>
</html>