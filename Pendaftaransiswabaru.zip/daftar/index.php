<?php
    include "config/konek.php";
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Pendaftaran</title>
        <link rel="stylesheet" type="text/css" href="style.css">    
    </head>

    <body>
        <div class="box-form">
            <form method="post" action="simpan.php" enctype="multipart/form-data">
                <center>
                <h2>FORMULIR PENDAFTARAN PESERTA DIDIK BARU TAHUN 2020-2021</h2>
                <h2>SMK Wikrama 1 Garut</h2>
                </center>
                <table>
                    <tr>
                        <td>Nomor Pendaftaran</td>
                        <td>
                            <input type="text" onkeyup="isi_otomatis()" name="no_pendaftaran">
                        </td>
                    </tr>

                    <tr>
                        <td>Nomor Tes</td>
                        <td>
                            <input type="text" onkeyup="isi_otomatis()" name="no_tes">
                        </td>
                    </tr>

                    <tr>
                        <td>Jalur Masuk</td>
                        <td>
                            <input type="radio" name="jalur_masuk" value="reguler" title="Reguler">Reguler &nbsp;&nbsp;&nbsp;
                            <input type="radio" name="jalur_masuk" value="beasiswa" title="Beasiswa">Beasiswa<br>
                        </td>
                    </tr>

                </table><br>

                <!-- Form Data Siswa -->
                <table>
                    <h4>I. DATA CALON MURID</h4><br>

                    <tr>
                        <td>Nama Lengkap</td>
                        <td>
                            <input type="text" name="nama_lengkap">
                        </td>
                    </tr>

                    <tr>
                        <td>Nama Panggilan</td>
                        <td>
                            <input type="text" name="nama_panggilan">
                        </td>
                    </tr>

                    <tr>
                        <td>Jenis Kelamin</td>
                        <td>
                            <input type="radio" name="jenis_kelamin" value="L" title="Pria">P &nbsp;&nbsp;&nbsp;
                            <input type="radio" name="jenis_kelamin" value="P" title="Wanita">W
                        </td>
                    </tr>

                    <tr>
                        <td>Tempat</td>
                        <td>
                            <input id="kecil" type="text" name="tempat">
                        </td>
                    </tr>

                    <tr>
                        <td>Tanggal Lahir</td>
                        <td>
                            <input type="date" name="tanggal_lahir">
                        </td>
                    </tr>

                    <tr>
                        <td>Agama</td>
                        <td>
                            <select name="agama">
                                <option selected>--Pilih--</option>
                                <option value="islam">Islam</option>
                                <option value="kristen">Kristen</option>
                                <option value="hindu">Hindu</option>
                                <option value="budha">Budha</option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <td>Cita Cita</td>
                        <td>
                            <input type="text" name="cita_cita">
                        </td>
                    </tr>

                    <tr>
                        <td>Hoby</td>
                        <td>
                            <input type="text" name="hoby">
                        </td>
                    </tr>

                    <tr>
                        <td>Anak Ke-</td>
                        <td>
                            <input type="text" name="anak_ke">
                        </td>
                    </tr>

                    <tr>
                        <td>Jumlah Sudara</td>
                        <td>
                            <input type="text" name="kandung" placeholder="--Kandung--">
                        </td>
                    </tr>

                    <tr>
                        <td>Jumlah Sudara</td>
                        <td>
                            <input type="text" name="tiri" placeholder="--Tiri--">
                        </td>
                    </tr>

                    <tr>
                        <td>Jumlah Sudara</td>
                        <td>
                            <input type="text" name="angkat" placeholder="--Angkat--">
                        </td>
                    </tr>

                    <tr>
                        <td>Berat Badan</td>
                        <td>
                            <input type="text" name="berat_badan">
                        </td>
                    </tr>

                    <tr>
                        <td>Tinggi Badan</td>
                        <td>
                            <input type="text" name="tinggi_badan">
                        </td>
                    </tr>

                    <tr>
                        <td>Golongan Darah</td>
                        <td>
                            <input type="text" name="golongan_darah">
                        </td>
                    </tr>

                </table><br>

                <!-- Form Alamat Siswa -->
                <table>
                    <h4>II. KETERANGAN TEMPAT TINGGAL</h4><br>

                    <tr>
                        <td>Alamat Rumah</td>
                        <td>
                            <textarea type="text" name="alamat" ></textarea>
                            <!-- <input type="text" name="rt" placeholder="RT">
                            <input type="text" name="rw" placeholder="RW"> -->
                        </td>
                    </tr>

                    <tr>
                        <td>Kelurahan</td>
                        <td>
                            <input type="text" name="kelurahan">
                        </td>
                    </tr>

                    <tr>
                        <td>Kecamatan</td>
                        <td>
                            <input type="text" name="kecamatan">
                        </td>
                    </tr>

                    <tr>
                        <td>Kabupaten Kota</td>
                        <td>
                            <input type="text" name="kabupaten_kota">
                        </td>
                    </tr>

                    <tr>
                        <td>Provinsi</td>
                        <td>
                            <input type="text" name="provinsi">
                        </td>
                    </tr>

                    <tr>
                        <td>Kode Pos</td>
                        <td>
                            <input type="text" name="kode pos" >
                        </td>
                    </tr>

                    <tr>
                        <td>Telepon Rumah</td>
                        <td>
                            <input type="text" name="no_telepon_rumah">
                        </td>
                    </tr>

                    <tr>
                        <td>Email</td>
                        <td>
                            <input type="email" name="email">
                        </td>
                    </tr>

                    <tr>
                        <td>Tinggal Dengan</td>
                        <td>
                            <input type="radio" name="tinggal_dengan" value="orang_tua" title="Orangtua">Orang Tua &nbsp;&nbsp;&nbsp;
                            <input type="radio" name="tinggal_dengan" value="asrama" title="Asrama">Asrama &nbsp;&nbsp;&nbsp;
                            <input type="radio" name="tinggal_dengan" value="saudara" title="Saudara">Saudara
                        </td>
                    </tr>

                </table>

                <table>

                    <tr>
                        <td colspan="2">
                            <input type="submit" value="Kirim">
                        </td>
                    </tr>

                </table>
            </form>
        </div>
    </body>
</html>

